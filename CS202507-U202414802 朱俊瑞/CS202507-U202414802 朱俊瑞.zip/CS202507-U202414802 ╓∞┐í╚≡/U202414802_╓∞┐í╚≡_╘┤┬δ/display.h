#pragma once
#ifndef DISPLAY
#define DISPLAY
#include "cnfparser.h"
void showclause(clause* clausearr);




#endif