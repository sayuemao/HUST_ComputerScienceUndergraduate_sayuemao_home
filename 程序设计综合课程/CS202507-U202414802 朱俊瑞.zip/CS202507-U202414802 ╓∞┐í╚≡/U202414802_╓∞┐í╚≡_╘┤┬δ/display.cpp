#include "display.h"
#include "cnfparser.h"
#include<iostream>
#include <cstdio>
using namespace std;
extern int boolnum, clausenum;

void showclause(clause* clausearr)
{
    printf("��Ԫ������%d �Ӿ�������%d\n", boolnum, clausenum);   //��debug����������
    clause* tempclause = clausearr;
    while (tempclause)
    {
        unit* tempunit = tempclause->firstunit;
        while (tempunit)
        {
            printf("%d ", tempunit->unitnum);
            tempunit = tempunit->nextunit;
        }
        printf("\n");
        tempclause = tempclause->nextclause;
    }
}